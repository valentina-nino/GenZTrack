import tkinter as tk
from tkinter import ttk, messagebox
import random
import math
import numpy as np
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from matplotlib import gridspec


BITS = 16
X_MIN = -1
X_MAX = 2

COLORS = {
    "bg":        "#0D1117",
    "surface":   "#161B22",
    "surface2":  "#1C2333",
    "border":    "#30363D",
    "accent":    "#2F81F7",
    "accent2":   "#3FB950",
    "accent3":   "#F78166",
    "text":      "#E6EDF3",
    "text2":     "#8B949E",
    "warning":   "#D29922",
}


def funcion_objetivo(x):
    return x * math.sin(10 * math.pi * x) + 1

def crear_individuo():
    return "".join(random.choice("01") for _ in range(BITS))

def binario_a_real(ind):
    return X_MIN + (int(ind, 2) / (2**BITS - 1)) * (X_MAX - X_MIN)

def fitness(ind):
    return funcion_objetivo(binario_a_real(ind))

def seleccion(poblacion):
    fs = [fitness(i) for i in poblacion]
    mn = min(fs)
    if mn < 0:
        fs = [f - mn + 1 for f in fs]
    total = sum(fs)
    probs = [f / total for f in fs]
    return random.choices(poblacion, weights=probs, k=1)[0]

def crossover(p1, p2, pc):
    if random.random() < pc:
        pt = random.randint(1, BITS - 2)
        return p1[:pt] + p2[pt:], p2[:pt] + p1[pt:]
    return p1, p2

def mutacion(ind, pm):
    return "".join(
        ("1" if b == "0" else "0") if random.random() < pm else b
        for b in ind
    )

# Interfaz Gráfica 

class App:

    def __init__(self, root):
        self.root = root
        self.root.title("Algoritmos Genéticos - Valentina Niño Solano")
        self.root.geometry("1300x860")
        self.root.configure(bg=COLORS["bg"])
        self.root.resizable(True, True)

        self._animando = False
        self._after_id = None

        self._build_ui()

    def _build_ui(self):
        # Header
        hdr = tk.Frame(self.root, bg=COLORS["surface"], height=64)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)

        tk.Label(
            hdr,
            text="ALGORITMOS GENÉTICOS",
            font=("Segoe UI", 22, "bold"),
            fg=COLORS["text"],
            bg=COLORS["surface"],
        ).pack(side="left", padx=28, pady=18)

        tk.Label(
            hdr,
            text="Optimización Evolutiva",
            font=("Segoe UI", 10),
            fg=COLORS["text2"],
            bg=COLORS["surface"],
        ).pack(side="left", pady=18)

        # Panel controles
        ctrl = tk.Frame(self.root, bg=COLORS["surface2"], pady=14)
        ctrl.pack(fill="x", padx=16, pady=(12, 0))

        params = [
            ("Población",    "100", "entry_pop"),
            ("Generaciones", "100", "entry_gen"),
            ("Crossover",    "0.8", "entry_cross"),
            ("Mutación",     "0.05","entry_mut"),
        ]

        for label, default, attr in params:
            frame = tk.Frame(ctrl, bg=COLORS["surface2"])
            frame.pack(side="left", padx=18)
            tk.Label(frame, text=label, font=("Segoe UI", 9),
                     fg=COLORS["text2"], bg=COLORS["surface2"]).pack(anchor="w")
            e = tk.Entry(frame, font=("Consolas", 12), width=8,
                         justify="center", bg=COLORS["surface"],
                         fg=COLORS["text"], insertbackground=COLORS["text"],
                         relief="flat", highlightthickness=1,
                         highlightbackground=COLORS["border"],
                         highlightcolor=COLORS["accent"])
            e.insert(0, default)
            e.pack()
            setattr(self, attr, e)

        # Velocidad
        spd_frame = tk.Frame(ctrl, bg=COLORS["surface2"])
        spd_frame.pack(side="left", padx=18)
        tk.Label(spd_frame, text="Velocidad", font=("Segoe UI", 9),
                 fg=COLORS["text2"], bg=COLORS["surface2"]).pack(anchor="w")
        self.speed_var = tk.StringVar(value="Normal")
        speeds = ["Lenta", "Normal", "Rápida", "Máx"]
        spd_inner = tk.Frame(spd_frame, bg=COLORS["surface2"])
        spd_inner.pack()
        self.speed_btns = {}
        for s in speeds:
            b = tk.Button(
                spd_inner, text=s, font=("Segoe UI", 9),
                bg=COLORS["surface"], fg=COLORS["text2"],
                relief="flat", padx=8, pady=3, cursor="hand2",
                activebackground=COLORS["accent"],
                activeforeground=COLORS["text"],
                command=lambda v=s: self._set_speed(v)
            )
            b.pack(side="left", padx=2)
            self.speed_btns[s] = b
        self._set_speed("Normal")

        # Botón
        self.btn = tk.Button(
            ctrl,
            text="▶  INICIAR",
            font=("Segoe UI", 11, "bold"),
            bg=COLORS["accent"],
            fg=COLORS["text"],
            relief="flat",
            padx=22, pady=8,
            cursor="hand2",
            activebackground="#1A6CC4",
            activeforeground=COLORS["text"],
            command=self._toggle,
        )
        self.btn.pack(side="right", padx=20)

        # Métricas
        metrics_frame = tk.Frame(self.root, bg=COLORS["bg"])
        metrics_frame.pack(fill="x", padx=16, pady=10)

        self.metric_vars = {}
        for label, key in [
            ("Generación",     "gen"),
            ("Mejor fitness",  "best"),
            ("Mejor x",        "x"),
            ("Fitness promedio","avg"),
        ]:
            mf = tk.Frame(metrics_frame, bg=COLORS["surface"],
                          padx=18, pady=10, relief="flat")
            mf.pack(side="left", fill="x", expand=True, padx=6)
            v = tk.StringVar(value="—")
            self.metric_vars[key] = v
            tk.Label(mf, textvariable=v, font=("Consolas", 17, "bold"),
                     fg=COLORS["text"], bg=COLORS["surface"]).pack()
            tk.Label(mf, text=label, font=("Segoe UI", 9),
                     fg=COLORS["text2"], bg=COLORS["surface"]).pack()

        # Barra de progreso
        prog_frame = tk.Frame(self.root, bg=COLORS["bg"])
        prog_frame.pack(fill="x", padx=22, pady=(0, 6))
        self.prog_label = tk.Label(
            prog_frame, text="", font=("Segoe UI", 9),
            fg=COLORS["text2"], bg=COLORS["bg"]
        )
        self.prog_label.pack(anchor="w")
        self.prog_var = tk.DoubleVar(value=0)
        style = ttk.Style()
        style.theme_use("default")
        style.configure(
            "GA.Horizontal.TProgressbar",
            troughcolor=COLORS["surface"],
            background=COLORS["accent"],
            thickness=6,
            borderwidth=0,
        )
        self.progressbar = ttk.Progressbar(
            prog_frame, variable=self.prog_var,
            maximum=100, style="GA.Horizontal.TProgressbar",
            length=400
        )
        self.progressbar.pack(fill="x")

        self._build_figure()

    def _set_speed(self, val):
        self.speed_var.set(val)
        for s, b in self.speed_btns.items():
            if s == val:
                b.config(bg=COLORS["accent"], fg=COLORS["text"])
            else:
                b.config(bg=COLORS["surface"], fg=COLORS["text2"])

    def _speed_ms(self):
        return {"Lenta": 300, "Normal": 80, "Rápida": 20, "Máx": 0}[self.speed_var.get()]

    def _build_figure(self):
        self.fig = Figure(figsize=(13, 5.5), dpi=100, facecolor=COLORS["bg"])
        self.fig.subplots_adjust(left=0.06, right=0.97, top=0.92,
                                  bottom=0.12, wspace=0.32)

        gs = gridspec.GridSpec(1, 3, figure=self.fig)

        ax_style = dict(
            facecolor=COLORS["surface"],
            labelcolor=COLORS["text2"],
        )

        self.ax_func = self.fig.add_subplot(gs[0])
        self.ax_fit  = self.fig.add_subplot(gs[1])
        self.ax_pop  = self.fig.add_subplot(gs[2])

        for ax in (self.ax_func, self.ax_fit, self.ax_pop):
            ax.set_facecolor(COLORS["surface"])
            ax.tick_params(colors=COLORS["text2"], labelsize=8)
            for spine in ax.spines.values():
                spine.set_edgecolor(COLORS["border"])
            ax.grid(True, color=COLORS["border"], linewidth=0.5, alpha=0.6)
            ax.title.set_color(COLORS["text"])
            ax.xaxis.label.set_color(COLORS["text2"])
            ax.yaxis.label.set_color(COLORS["text2"])

        self._init_plots()

        self.canvas = FigureCanvasTkAgg(self.fig, master=self.root)
        self.canvas.get_tk_widget().pack(fill="both", expand=True, padx=16, pady=(0, 12))

    def _init_plots(self):
        x_curve = np.linspace(X_MIN, X_MAX, 800)
        y_curve = [funcion_objetivo(v) for v in x_curve]

        # Función objetivo
        self.ax_func.clear()
        self.ax_func.set_facecolor(COLORS["surface"])
        self.ax_func.plot(x_curve, y_curve, color=COLORS["accent"],
                          linewidth=1.4, zorder=2)
        self.ax_func.set_title("Función objetivo", fontsize=11, pad=8)
        self.ax_func.set_xlabel("x", fontsize=9)
        self.ax_func.set_ylabel("f(x)", fontsize=9)
        self.ax_func.grid(True, color=COLORS["border"], lw=0.5, alpha=0.6)
        for sp in self.ax_func.spines.values():
            sp.set_edgecolor(COLORS["border"])
        self.ax_func.tick_params(colors=COLORS["text2"], labelsize=8)
        self._opt_point, = self.ax_func.plot(
            [], [], "o", color=COLORS["accent3"],
            markersize=10, zorder=5,
            markeredgecolor=COLORS["text"], markeredgewidth=1.2
        )
        self._opt_vline = self.ax_func.axvline(
            x=0, color=COLORS["accent3"], lw=0.8,
            linestyle="--", alpha=0, zorder=1
        )
        self._x_curve = x_curve
        self._y_curve = y_curve

        # Evolución fitness
        self.ax_fit.clear()
        self.ax_fit.set_facecolor(COLORS["surface"])
        self.ax_fit.set_title("Evolución del fitness", fontsize=11, pad=8)
        self.ax_fit.set_xlabel("Generación", fontsize=9)
        self.ax_fit.set_ylabel("Fitness", fontsize=9)
        self.ax_fit.grid(True, color=COLORS["border"], lw=0.5, alpha=0.6)
        for sp in self.ax_fit.spines.values():
            sp.set_edgecolor(COLORS["border"])
        self.ax_fit.tick_params(colors=COLORS["text2"], labelsize=8)
        self._line_best, = self.ax_fit.plot(
            [], [], color=COLORS["accent2"], lw=2, label="Mejor"
        )
        self._line_avg, = self.ax_fit.plot(
            [], [], color=COLORS["warning"], lw=1.4,
            linestyle="--", label="Promedio", alpha=0.85
        )
        self.ax_fit.legend(
            facecolor=COLORS["surface2"], edgecolor=COLORS["border"],
            labelcolor=COLORS["text2"], fontsize=8
        )

        # Distribución población
        self.ax_pop.clear()
        self.ax_pop.set_facecolor(COLORS["surface"])
        self.ax_pop.set_title("Distribución de la población", fontsize=11, pad=8)
        self.ax_pop.set_xlabel("x", fontsize=9)
        self.ax_pop.set_ylabel("f(x)", fontsize=9)
        self.ax_pop.grid(True, color=COLORS["border"], lw=0.5, alpha=0.6)
        for sp in self.ax_pop.spines.values():
            sp.set_edgecolor(COLORS["border"])
        self.ax_pop.tick_params(colors=COLORS["text2"], labelsize=8)
        self.ax_pop.plot(
            x_curve, y_curve,
            color=COLORS["accent"], lw=1.2, alpha=0.35, zorder=1
        )
        self._scat_pop = self.ax_pop.scatter(
            [], [], c=COLORS["accent"], s=18,
            alpha=0.7, zorder=3, edgecolors="none"
        )
        self._scat_best_pop = self.ax_pop.scatter(
            [], [], c=COLORS["accent3"], s=90,
            zorder=5, edgecolors=COLORS["text"], linewidths=1.2
        )

        self.canvas.draw() if hasattr(self, "canvas") else None

    # --------------------------------------------------
    # ALGORITMO
    # --------------------------------------------------

    def _toggle(self):
        if self._animando:
            self._animando = False
            if self._after_id:
                self.root.after_cancel(self._after_id)
            self.btn.config(text="▶  REANUDAR", bg=COLORS["accent2"])
        else:
            self._run()

    def _run(self):
        try:
            NPOP  = int(self.entry_pop.get())
            NGEN  = int(self.entry_gen.get())
            PC    = float(self.entry_cross.get())
            PM    = float(self.entry_mut.get())
        except ValueError:
            messagebox.showerror("Error", "Revisa los parámetros ingresados.")
            return

        self._animando = True
        self.btn.config(text="⏸  PAUSAR", bg=COLORS["warning"])
        self._init_plots()

        # Pre-calcular todas las generaciones
        pop = [crear_individuo() for _ in range(NPOP)]
        self._snapshots = []
        mejor_global, mejor_f_global = None, -1e9

        for g in range(NGEN):
            fs = [fitness(ind) for ind in pop]
            idx = int(np.argmax(fs))
            bF = fs[idx]
            avg = float(np.mean(fs))
            if bF > mejor_f_global:
                mejor_f_global = bF
                mejor_global = pop[idx]
            self._snapshots.append({
                "pop": list(pop),
                "best": mejor_global,
                "bestF": mejor_f_global,
                "avg": avg,
                "gen": g + 1,
                "total": NGEN,
            })
            nueva = [pop[idx]]
            while len(nueva) < NPOP:
                c1, c2 = crossover(seleccion(pop), seleccion(pop), PC)
                nueva.append(mutacion(c1, PM))
                if len(nueva) < NPOP:
                    nueva.append(mutacion(c2, PM))
            pop = nueva

        self._hist_best = []
        self._hist_avg  = []
        self._gen_idx   = 0
        self._animate_step()

    def _animate_step(self):
        if not self._animando:
            return
        if self._gen_idx >= len(self._snapshots):
            self._animando = False
            self.btn.config(text="↺  REINICIAR", bg=COLORS["accent"])
            return

        snap = self._snapshots[self._gen_idx]
        g, total = snap["gen"], snap["total"]
        bF, avg  = snap["bestF"], snap["avg"]
        best_ind = snap["best"]
        bx = binario_a_real(best_ind)

        # Métricas
        self.metric_vars["gen"].set(f"{g}")
        self.metric_vars["best"].set(f"{bF:.5f}")
        self.metric_vars["x"].set(f"{bx:.5f}")
        self.metric_vars["avg"].set(f"{avg:.5f}")

        # Progreso
        pct = g / total * 100
        self.prog_var.set(pct)
        self.prog_label.config(text=f"Generación {g} de {total}")

        # Historial
        self._hist_best.append(bF)
        self._hist_avg.append(avg)
        gens = list(range(1, g + 1))

        # Gráfica función — punto óptimo
        by = funcion_objetivo(bx)
        self._opt_point.set_data([bx], [by])
        self._opt_vline.set_xdata([bx, bx])
        self._opt_vline.set_alpha(0.4)

        # Gráfica fitness
        self._line_best.set_data(gens, self._hist_best)
        self._line_avg.set_data(gens, self._hist_avg)
        self.ax_fit.set_xlim(1, max(total, 2))
        all_vals = self._hist_best + self._hist_avg
        mn, mx = min(all_vals), max(all_vals)
        pad = max((mx - mn) * 0.1, 0.05)
        self.ax_fit.set_ylim(mn - pad, mx + pad)

        # Gráfica distribución
        xs_pop = [binario_a_real(ind) for ind in snap["pop"]]
        ys_pop = [funcion_objetivo(x) for x in xs_pop]
        self._scat_pop.set_offsets(list(zip(xs_pop, ys_pop)))
        self._scat_best_pop.set_offsets([[bx, by]])

        self.canvas.draw_idle()

        self._gen_idx += 1
        ms = self._speed_ms()
        if ms == 0:
            # Saltar al final de golpe
            while self._gen_idx < len(self._snapshots):
                s2 = self._snapshots[self._gen_idx]
                self._hist_best.append(s2["bestF"])
                self._hist_avg.append(s2["avg"])
                self._gen_idx += 1
            last = self._snapshots[-1]
            bx2 = binario_a_real(last["best"])
            self.metric_vars["gen"].set(str(last["gen"]))
            self.metric_vars["best"].set(f"{last['bestF']:.5f}")
            self.metric_vars["x"].set(f"{bx2:.5f}")
            self.metric_vars["avg"].set(f"{last['avg']:.5f}")
            self.prog_var.set(100)
            self.prog_label.config(text=f"Generación {total} de {total}")
            gens2 = list(range(1, total + 1))
            self._line_best.set_data(gens2, self._hist_best)
            self._line_avg.set_data(gens2, self._hist_avg)
            self.ax_fit.set_xlim(1, total)
            by2 = funcion_objetivo(bx2)
            self._opt_point.set_data([bx2], [by2])
            xs2 = [binario_a_real(i) for i in last["pop"]]
            ys2 = [funcion_objetivo(x) for x in xs2]
            self._scat_pop.set_offsets(list(zip(xs2, ys2)))
            self._scat_best_pop.set_offsets([[bx2, by2]])
            self.canvas.draw_idle()
            self._animando = False
            self.btn.config(text="↺  REINICIAR", bg=COLORS["accent"])
        else:
            self._after_id = self.root.after(ms, self._animate_step)

# Main

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()